<head>
<title>FORGOT PASSWORD</title>
    <link rel="stylesheet" type="text/css" href="forgotpass.css">
<body>

    <div class="loginbox">
            <h1><i class="fas fa-lock"></i></h1>
        <form action="" method="POST">
            <center><label>ENTER EMAIL ADDRESS</label></center>
            <input type="text" name="username" placeholder="Enter Email Address">

            <input type="submit" name="login" value="Send Log-in Link">
           <center> <label>--------------OR-------------</label></center>	
           <center> <BUTTON style="border-radius:5px;"><a href="index.php">BACK TO LOGIN</a></BUTTON><br>
            <BUTTON style="border-radius:15px;"><a href="signup.php">CREATE ACCOUNT</a></BUTTON></center>
        </form>
    </div>
</section>
</body>
</head>
</html>